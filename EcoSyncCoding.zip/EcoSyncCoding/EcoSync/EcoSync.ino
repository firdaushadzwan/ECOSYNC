#include <Adafruit_Sensor.h>
#include <DHT.h>
#include <DHT_U.h>
#include <Stepper.h>

#define DHTPIN 7          // DHT11 sensor data pin
#define DHTTYPE DHT11     // DHT sensor type

// Stepper motor setup
const int stepsPerRevolution = 2048;  // For 28BYJ-48 stepper

// IN1=8, IN2=10, IN3=9, IN4=11
Stepper stepper(stepsPerRevolution, 8, 10, 9, 11);

// Temperature thresholds
#define TEMPERATURE_THRESHOLD 26
#define TEMPERATURE_THRESHOLD1 32

DHT dht(DHTPIN, DHTTYPE);

float currentRPM = 0;  // Store current RPM for printing

void setup() {
  Serial.begin(9600);
  dht.begin();

  stepper.setSpeed(5); // Initial speed
  currentRPM = 5;
}

void loop() {
  float temperature = dht.readTemperature();

  if (isnan(temperature)) {
    Serial.println("Failed to read temperature from DHT sensor!");
    return;
  }

  // Control stepper motor based on temperature
  if (temperature > TEMPERATURE_THRESHOLD1) {
    currentRPM = 11;
    stepper.setSpeed(currentRPM);
    stepper.step(stepsPerRevolution); // One full rotation
  }
  else if (temperature > TEMPERATURE_THRESHOLD) {
    currentRPM = 8;
    stepper.setSpeed(currentRPM);
    stepper.step(stepsPerRevolution / 2); // Half rotation
  }
  else {
    currentRPM = 3;
    stepper.setSpeed(currentRPM);
    stepper.step(stepsPerRevolution / 4); // Quarter rotation
  }

  // Print temperature and motor RPM
  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" °C");

  Serial.print("Motor Speed: ");
  Serial.print(currentRPM);
  Serial.println(" RPM");
  Serial.println("--------------------");
}
